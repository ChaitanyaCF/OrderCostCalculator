Please place the CFT logo image file in this directory.
Recommended filename: cft-logo.png

The image should be the red fish logo as shown in the provided reference image.