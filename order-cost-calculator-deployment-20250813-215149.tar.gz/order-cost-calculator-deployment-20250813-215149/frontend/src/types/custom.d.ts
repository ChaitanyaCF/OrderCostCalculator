declare module "*.csv" {
    const content: string;
    export default content;
} 