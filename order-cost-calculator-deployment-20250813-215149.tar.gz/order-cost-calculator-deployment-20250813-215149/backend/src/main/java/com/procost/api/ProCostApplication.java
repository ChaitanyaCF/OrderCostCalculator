package com.procost.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProCostApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(ProCostApplication.class, args);
    }
}