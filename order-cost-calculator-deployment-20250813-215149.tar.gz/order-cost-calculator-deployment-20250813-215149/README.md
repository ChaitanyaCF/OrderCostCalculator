# Order Cost Calculator - Deployment Package

## 🚀 Quick Start

### Docker Deployment (Recommended)
```bash
# 1. Set your OpenAI API key
export OPENAI_API_KEY="your-api-key-here"

# 2. Deploy
./deploy-local-docker.sh
```

### Kubernetes Deployment
```bash
# 1. Deploy to cluster
./deploy-kubernetes.sh
```

## 📊 Features Included

- ✅ **Conversation Progression**: Email threading and status tracking
- ✅ **AI Integration**: OpenAI-powered email classification
- ✅ **Enhanced Dashboard**: Real-time enquiry and order management
- ✅ **Docker Support**: Full containerization with Docker Compose
- ✅ **Kubernetes Ready**: Production-ready K8s manifests
- ✅ **Health Monitoring**: Built-in health checks and logging

## 📖 Documentation

See `DEPLOYMENT_GUIDE.md` for detailed instructions.

## 🆘 Support

For issues or questions:
1. Check the deployment guide
2. Review application logs
3. Test with provided curl commands

## 🏷️ Version

Built on: $(date)
Features: Conversation Progression, Enhanced Logging, AI Classification
